export const config = {
  STRIPE_PUBLISHABLE_KEY:
    "pk_test_51Jh1niE823uteDHEJY8cM7f4GsQSj1J6KhaYKsDYpGng9jJKDYh2nKKjpZye9wqsTygl7BbLr3MFNu82JgIMGIwD00MyuUfeta",
};
